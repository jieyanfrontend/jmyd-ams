module.exports = {
  parser: 'flow',
  singleQuote: true,
  printWidth: 120,
  jsxBracketSameLine: false,
  trailingComma: 'none',
  trailingComma: 'es5',
};
