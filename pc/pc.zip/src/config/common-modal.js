export default {
  width: 800,
  maskClosable: false
}