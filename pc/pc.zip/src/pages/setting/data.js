import moment  from 'moment';
export default [{
    task_type: '事务件',
    time_warn: '72h',
    time_out: '48'
},{
    task_type: '报告件',
    time_warn: '48h',
    time_out: '24h'
}]