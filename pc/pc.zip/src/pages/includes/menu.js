const menu = [{
  title: 'AMS工单提醒',
  path: '/task'
}, {
  title: '批量处理任务',
  path: '/batch_process'
}, {
  title: '设置',
  path: '/setting'
}, {
  title: '退出',
  path: '/login'
}];
export default menu;