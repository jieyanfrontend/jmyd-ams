let handleJson = (data) => {
    return JSON.stringify(data);
};
export default handleJson;