# 安装yarn
# 安装依赖
```
yarn install
```
#开始编程
```
npm start
```
# 编译部署
```markdown
npm run build
```